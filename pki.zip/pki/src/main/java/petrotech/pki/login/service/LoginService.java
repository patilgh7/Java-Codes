package petrotech.pki.login.service;

import org.springframework.stereotype.Service;


@Service
public interface LoginService {

	

	public boolean authenticateUser(String userName , String password) ;
	
}
