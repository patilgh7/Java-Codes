package petrotech.pki.login.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import petrotech.pki.login.dao.UserDetailsDao;
import petrotech.pki.login.pojo.LoginRequest;

@Repository
public interface LoginRepository extends JpaRepository<UserDetailsDao, Long>{

	@Query(value = "SELECT  count(*) from user_details WHERE user_id = ?1 and password = ?2",nativeQuery = true)
	int findByUsernameAndPassword(String userId, String password);
	
}
