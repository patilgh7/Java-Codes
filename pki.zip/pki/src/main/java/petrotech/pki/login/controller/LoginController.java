package petrotech.pki.login.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import petrotech.pki.login.pojo.LoginRequest;
import petrotech.pki.login.service.LoginService;

@RestController
public class LoginController {

	@Autowired
	private LoginService loginService;

	//@GetMapping("/pki/login")

	@PostMapping("/pki/login")
	public ResponseEntity<String> login(@RequestBody LoginRequest loginRequest) {
		// Validate credentials
		boolean isValid = loginService.authenticateUser(loginRequest.getUsername(), loginRequest.getPassword());
		if (isValid) {

			return ResponseEntity.ok("Login successful!");
		} else {
			// Return error message
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid username or password");
		}
	}




}
