package petrotech.pki.login.impl;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import petrotech.pki.login.dao.UserDetailsDao;
import petrotech.pki.login.pojo.LoginRequest;
import petrotech.pki.login.repository.LoginRepository;
import petrotech.pki.login.service.LoginService;

@Component
public class LoginServiceImpl implements LoginService {

	@Autowired
	LoginRepository loginRepository;

	private boolean validateCredentials(String username, String password) {
        // Check if username and password are valid
        if (username != null && !"".equals(username) && password!= null  && !"".equals(password)) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean authenticateUser(String userName, String password) {

        if(validateCredentials(userName,password)) {
            System.out.println("userName-->"+userName);
            int daoCount = loginRepository.findByUsernameAndPassword(userName, password);
            if (daoCount > 0)
                return true;
        }
        return false;
    }


}
