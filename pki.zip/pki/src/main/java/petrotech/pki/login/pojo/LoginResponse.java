package petrotech.pki.login.pojo;

public class LoginResponse {

}
