package petrotech.pki.login;

public interface UserOperations {

	// Check username and password
	
	
}
