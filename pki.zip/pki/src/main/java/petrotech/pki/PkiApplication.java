package petrotech.pki;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import petrotech.pki.login.controller.LoginController;

@SpringBootApplication
public class PkiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PkiApplication.class, args);

		
	}

}
