package petrotech.pki.boardoperations.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import petrotech.pki.boardoperations.dao.BoardDetailsDao;
import petrotech.pki.boardoperations.pojo.BoardRequest;
import petrotech.pki.boardoperations.service.BoardService;

@RestController
public class BoardController {

    @Autowired
    BoardService boardService;


    @PostMapping("/pki/getboarddetails")
    public ResponseEntity<BoardDetailsDao> getBoardDetailsById(@RequestBody BoardRequest boardRequest){

        BoardDetailsDao boardDetailsDao = boardService.getBoardDetails(boardRequest.getBoardId());

        return ResponseEntity.ok(boardDetailsDao);

    }



}
