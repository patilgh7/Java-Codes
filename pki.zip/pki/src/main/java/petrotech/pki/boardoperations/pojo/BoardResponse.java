package petrotech.pki.boardoperations.pojo;

public class BoardResponse {
}
