package petrotech.pki.boardoperations.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import petrotech.pki.boardoperations.dao.BoardDetailsDao;
import petrotech.pki.boardoperations.repository.BoardRepository;
import petrotech.pki.boardoperations.service.BoardService;

@Component
public class BoardServiceImpl implements BoardService {

    @Autowired
    BoardRepository boardRepository;

    public BoardDetailsDao getBoardDetails(long id){

        BoardDetailsDao dao = boardRepository.findBoardDetailsDaoById(id);
        return dao;
    }

}
