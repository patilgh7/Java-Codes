package petrotech.pki.boardoperations.service;

import org.springframework.stereotype.Service;
import petrotech.pki.boardoperations.dao.BoardDetailsDao;

@Service
public interface BoardService {

    public BoardDetailsDao getBoardDetails(long id);

}
