package petrotech.pki.boardoperations.dao;

import javax.persistence.*;

@Entity
@Table(name = "board_details")
public class BoardDetailsDao {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long pkBoardDetailsId;

    private long serialNumber;

    private String boardType;

    private String privateKey;

    private String generatedDate;

    private String purpose;

    private long customerOrderNumber;

    private String certificate;

    private String certificateSign;

    private String certificateExpiryDate;

    private String generatedBy;

    private long boardId;

    private String pivateKey;


    public long getPkBoardDetailsId() {
        return pkBoardDetailsId;
    }

    public void setPkBoardDetailsId(long pkBoardDetailsId) {
        this.pkBoardDetailsId = pkBoardDetailsId;
    }

    public long getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(long serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getBoardType() {
        return boardType;
    }

    public void setBoardType(String boardType) {
        this.boardType = boardType;
    }

    public String getPrivateKey() {
        return privateKey;
    }

    public void setPrivateKey(String privateKey) {
        this.privateKey = privateKey;
    }

    public String getGeneratedDate() {
        return generatedDate;
    }

    public void setGeneratedDate(String generatedDate) {
        this.generatedDate = generatedDate;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public long getCustomerOrderNumber() {
        return customerOrderNumber;
    }

    public void setCustomerOrderNumber(long customerOrderNumber) {
        this.customerOrderNumber = customerOrderNumber;
    }

    public String getCertificate() {
        return certificate;
    }

    public void setCertificate(String certificate) {
        this.certificate = certificate;
    }

    public String getCertificateSign() {
        return certificateSign;
    }

    public void setCertificateSign(String certificateSign) {
        this.certificateSign = certificateSign;
    }

    public String getCertificateExpiryDate() {
        return certificateExpiryDate;
    }

    public void setCertificateExpiryDate(String certificateExpiryDate) {
        this.certificateExpiryDate = certificateExpiryDate;
    }

    public String getGeneratedBy() {
        return generatedBy;
    }

    public void setGeneratedBy(String generatedBy) {
        this.generatedBy = generatedBy;
    }

    public long getBoardId() {
        return boardId;
    }

    public void setBoardId(long boardId) {
        this.boardId = boardId;
    }

    public String getPivateKey() {
        return pivateKey;
    }

    public void setPivateKey(String pivateKey) {
        this.pivateKey = pivateKey;
    }


    @Override
    public String toString() {
        return "BoardDetailsDao{" +
                "pkBoardDetailsId=" + pkBoardDetailsId +
                ", serialNumber=" + serialNumber +
                ", boardType='" + boardType + '\'' +
                ", privateKey='" + privateKey + '\'' +
                ", generatedDate='" + generatedDate + '\'' +
                ", purpose='" + purpose + '\'' +
                ", customerOrderNumber=" + customerOrderNumber +
                ", certificate='" + certificate + '\'' +
                ", certificateSign='" + certificateSign + '\'' +
                ", certificateExpiryDate='" + certificateExpiryDate + '\'' +
                ", generatedBy='" + generatedBy + '\'' +
                ", boardId=" + boardId +
                ", pivateKey='" + pivateKey + '\'' +
                '}';
    }

}
