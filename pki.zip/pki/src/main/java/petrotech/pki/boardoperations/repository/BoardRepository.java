package petrotech.pki.boardoperations.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import petrotech.pki.boardoperations.dao.BoardDetailsDao;

@Repository
public interface BoardRepository extends JpaRepository<BoardDetailsDao, Long> {

    @Query(value = "SELECT * FROM board_details WHERE pk_board_details_id = ?1",nativeQuery = true)
    BoardDetailsDao findBoardDetailsDaoById(Long id);



}
