package petrotech.pki.boardoperations.pojo;

public class BoardRequest {

    private long boardId;

    public long getBoardId() {
        return boardId;
    }

    public void setBoardId(long boardId) {
        this.boardId = boardId;
    }

    @Override
    public String toString() {
        return "BoardRequest{" +
                "boardId=" + boardId +
                '}';
    }
}
